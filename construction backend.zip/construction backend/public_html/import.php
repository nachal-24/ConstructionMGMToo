<?php
session_start();

if(!isset($_SESSION['user']))
{
 header("Location: login.php");
}
if(isset($_POST["Import"]))
{
    //First we need to make a connection with the database
   require_once __DIR__ . '/db_config.php';

   $con = mysqli_connect(DB_SERVER,DB_USER,DB_PASSWORD,DB_DATABASE) or die("DB connection error");
mysqli_select_db($con,DB_DATABASE) or die ("no database");


    echo $filename=$_FILES["file"]["tmp_name"];
    if($_FILES["file"]["size"] > 0)
    {
        $file = fopen($filename, "r");
        //$sql_data = "SELECT * FROM prod_list_1 ";
$i=1;
        while (($emapData = fgetcsv($file, 10000, ",")) !== FALSE)
        {
            //print_r($emapData);
            //exit();
if($i==1)
{$i=2;}
else{

            $sql = "INSERT into projecttask(taskname,duration,startdate,finishdate,predecessors,resources,type,esttotcost,status) values ('$emapData[0]','$emapData[1]','$emapData[2]','$emapData[3]','$emapData[4]','$emapData[5]','$emapData[6]','$emapData[7]','N')";
            mysqli_query($con,$sql);
}
        }
        fclose($file);
        echo 'CSV File has been successfully Imported';
        header('Location: login.php');
    }
    else
        echo 'Invalid File:Please Upload CSV File';
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['email']; ?></title>
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>
<div id="header">
 <div id="left">
    <label>Import</label>
    </div>
    <div id="right">
     <div id="content">
         hi' <?php echo $userRow['username']; ?>&nbsp;<a href="logout.php?logout">Sign Out</a>
        </div>
    </div>
</div>

<center>
<div>
<form enctype="multipart/form-data" method="post" role="form">
    <div class="form-group">
<table align="center"  border="0">
<tr>
        <td><label for="exampleInputFile">File Upload</label></td>
<td>        <input type="file" name="file" id="file" size="150"></td></tr>
<tr><td colspan="2">Only Excel CSV File Import.</td></tr>
        <tr >
<td colspan="2"><button type="submit" class="btn btn-default" name="Import" value="Import">Upload</button></td></tr>
</table>
    </div>
   
</form>
</div>
</center>
</body>
</html>