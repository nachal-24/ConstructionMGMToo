<?php

  // array for JSON response
$response = array();

// include db connect class
//require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/db_config.php';
// connecting to db
//$db = new DB_CONNECT();
  
 //$con=$db->db_connect(); 
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASSWORD,DB_DATABASE) or die("DB connection error");
mysqli_select_db($con,DB_DATABASE) or die ("no database");
// check for required fields
  if (isset($_POST['email']) && isset($_POST['password'])) {
 
$password = $_POST['password'];
$email= $_POST['email'];


$result = mysqli_query($con,"UPDATE userlogin 
SET 
password='$password'
where username='$email'");

 // check if row inserted or not
    if ($result) {
        // successfully inserted into database
        $response["success"] = 1;
        $response["message"] = "Task successfully created.";
 
        // echoing JSON response
       print(json_encode($response));
    } else {
        // failed to insert row
        $response["success"] = 0;
        $response["message"] = "Oops! An error occurred.";
 
        // echoing JSON response
        print(json_encode($response));
    }
    
  
 } else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) missing";

    // echoing JSON response
    print(json_encode($response));
}

//$db->db_close();
mysqli_close($con);
?> 