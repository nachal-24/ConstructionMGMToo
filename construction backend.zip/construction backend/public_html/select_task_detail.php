<?php

  // array for JSON response
$response = array();

// include db connect class
//require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/db_config.php';
// connecting to db
//$db = new DB_CONNECT();
  
 //$con=$db->db_connect(); 
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASSWORD,DB_DATABASE) or die("DB connection error");
mysqli_select_db($con,DB_DATABASE) or die ("no database");

// check for required fields
  if (isset($_POST['id'])) {
 
$id = $_POST['id'];



$result = mysqli_query($con,"SELECT * FROM projecttask where id = $id ");
if (!empty($result)){

 // check if row inserted or not
    if (mysqli_num_rows($result) > 0) {

	$row=mysqli_fetch_row($result);

        // successfully inserted into database
        $response["taskname"] = $row[1];
        $response["duration"] = $row[2];
	$response["startdate"] = $row[3];
	$response["finishdate"] = $row[4];
	$response["predecessors"] = $row[5];
	$response["resources"] = $row[6];
	$response["status"] = $row[7];
        $response["statuspercent"] = $row[11];
        
// echoing JSON response
       print(json_encode($response));
    } else {
        // failed to insert row
        $response["success"] = 0;
        $response["message"] = "Oops! An error occurred.";
 
        // echoing JSON response
        print(json_encode($response));
    }
    }
else{
 // failed to insert row
        $response["success"] = 0;
        $response["message"] = "Oops! No rows returned.";
 
        // echoing JSON response
        print(json_encode($response));
}
  
 } else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) missing";

    // echoing JSON response
    print(json_encode($response));
}

//$db->db_close();
mysqli_close($con);
?> 