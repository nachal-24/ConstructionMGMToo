<?php
//include('configNew.php');

// Path to move uploaded files
$target_path = "uploads/";
$target_path1 = "uploads/174/";
 
// array for final json respone
$response = array();
 
// getting server ip address
$server_ip = gethostbyname(gethostname());
 
// final file url that is being uploaded
$file_upload_url = 'http://iotycs.com/WS/' . $target_path;
//$file_upload_url = 'images' . '/';
 
 
if (isset($_FILES['image']['name'])) {
    //$target_path = $target_path1 . basename($_FILES['image']['name']);
    
    // reading other post parameters
    $doc_type = isset($_POST['doc_type']) ? $_POST['doc_type'] : '';
    $eid = isset($_POST['eid']) ? $_POST['eid'] : '';
    $filepath = $file_upload_url . '/' . $eid . '/' . basename($_FILES['image']['name']);
    
    $file_upload_url = $file_upload_url . '/' .$eid . '/';
    
    $target_path = $target_path . $eid . '/' . basename($_FILES['image']['name']);
    
    if (!file_exists('uploads/' . $eid)){
	mkdir('uploads/' . $eid, 0777, true);
    }
    
    //mysql_query("INSERT INTO `tbl_emergency_docs` (`eid`, `doc_path`, `doc_type`, `reg_date`) VALUES (".$eid.", '".$filepath."', '".$doc_type."', Now())");
 
    $response['file_name'] = basename($_FILES['image']['name']);
    $response['email'] = $email;
    $response['website'] = $website;
 
    try {
        // Throws exception incase file is not being moved
        if (!move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
            // make error flag true
            $response['error'] = true;
            $response['message'] = 'Could not move the file!';
        }
 
        // File successfully uploaded
        //$response['message'] = 'File uploaded successfully!';
        $response['message'] = $target_path;
        $response['error'] = false;
        $response['file_path'] = $file_upload_url . basename($_FILES['image']['name']);
    } catch (Exception $e) {
        // Exception occurred. Make error flag true
        $response['error'] = true;
        $response['message'] = $e->getMessage();
    }
} else {
    // File parameter is missing
    $response['error'] = true;
    $response['message'] = 'Not received any file!F';
}
 
// Echo final json response to client
echo json_encode($response);
?>