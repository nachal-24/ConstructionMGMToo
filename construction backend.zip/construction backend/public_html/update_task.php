<?php

  // array for JSON response
$response = array();

// include db connect class
//require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/db_config.php';
// connecting to db
//$db = new DB_CONNECT();
  
 //$con=$db->db_connect(); 
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASSWORD,DB_DATABASE) or die("DB connection error");
mysqli_select_db($con,DB_DATABASE) or die ("no database");
// check for required fields
  if (isset($_POST['id']) && isset($_POST['status']) && isset($_POST['statuspercent']) && isset($_POST['actualenddate'])) {
 
$id = $_POST['id'];
$status= $_POST['status'];
$statuspercent= $_POST['statuspercent'];
$actualenddate= $_POST['actualenddate'];


$result = mysqli_query($con,"UPDATE projecttask 
SET 
actualenddate='$actualenddate', 
status='$status', 
statuspercent='$statuspercent', 
actualstartdate=IF(actualstartdate IS NULL,'$actualenddate',actualstartdate)
where id=$id");

 // check if row inserted or not
    if ($result) {
        // successfully inserted into database
        $response["success"] = 1;
        $response["message"] = "Task successfully created.";
 
        // echoing JSON response
       print(json_encode($response));
    } else {
        // failed to insert row
        $response["success"] = 0;
        $response["message"] = "Oops! An error occurred.";
 
        // echoing JSON response
        print(json_encode($response));
    }
    
  
 } else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) missing";

    // echoing JSON response
    print(json_encode($response));
}

//$db->db_close();
mysqli_close($con);
?> 