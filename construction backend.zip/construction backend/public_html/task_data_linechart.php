<?php

  // array for JSON response
$response = array();

// include db connect class
require_once __DIR__ . '/db_config.php';

$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASSWORD,DB_DATABASE) or die("DB connection error");
mysqli_select_db($con,DB_DATABASE) or die ("no database");

$result = mysqli_query($con,"SELECT finishdate,SUM(esttotcost) FROM projecttask
WHERE TYPE =  'T' GROUP BY finishdate ORDER BY finishdate");

$result1 = mysqli_query($con,"SELECT finishdate,SUM(actualtotcost) FROM projecttask
WHERE TYPE =  'T' AND actualenddate IS NOT NULL GROUP BY finishdate ORDER BY finishdate");

$result2 = mysqli_query($con,"SELECT actualenddate,SUM(esttotcost) FROM projecttask
WHERE TYPE =  'T' AND actualenddate IS NOT NULL GROUP BY actualenddate ORDER BY actualenddate");

if(!empty($result) && !empty($result1) && !empty($result2)){


 // check if row inserted or not
    if ((mysqli_num_rows($result) > 0) && (mysqli_num_rows($result1) > 0) && (mysqli_num_rows($result2) > 0)) {
        // successfully inserted into database
//$result = mysqli_fetch_array($result);

$response["task"] = array();

while ($row=mysqli_fetch_row($result)){
$arraytask=array();
$arraytask["enddate"]=$row[0];
$arraytask["cost"]=$row[1];
array_push($response["task"], $arraytask);
}
//$response["$task"] = array();
//array_push($response["$task"], $arraytask);



$response["actual"] = array();

while ($row=mysqli_fetch_row($result1)){
$arraytask=array();
$arraytask["actualenddate"]=$row[0];
$arraytask["actualcost"]=$row[1];
array_push($response["actual"], $arraytask);
}

$response["earnedvalue"] = array();

while ($row=mysqli_fetch_row($result2)){
$arraytask=array();
$arraytask["eaenddate"]=$row[0];
$arraytask["eacost"]=$row[1];
array_push($response["earnedvalue"], $arraytask);
}

        // echoing JSON response
       print(json_encode($response));
mysqli_free_result($result);
    } else {
        // failed to insert row
        $response["id"] = 0;
        $response["taskname"] = "Oops! An error occurred.";

        // echoing JSON response
        print(json_encode($response));
    }


 } else {
    // required field is missing
    $response["id"] = 0;
    $response["taskname"] = "Required field(s) missing";

    // echoing JSON response
    print(json_encode($response));
}

//$db->db_close();
mysqli_close($con);
?>