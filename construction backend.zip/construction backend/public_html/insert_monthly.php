<?php

  // array for JSON response
$response = array();

// include db connect class
require_once __DIR__ . '/db_config.php';
//require_once __DIR__ . '/db_connect.php';

define('DB_USER', "u550870318_ivap"); // db user
define('DB_PASSWORD', "15-11-1990"); // db password (mention your db password here)
define('DB_DATABASE', "u550870318_test"); // database name
define('DB_SERVER', "mysql.hostinger.in");// db server

$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASSWORD,DB_DATABASE) or die("DB connection error");
mysqli_select_db($con,DB_DATABASE) or die ("no database");

// check for required fields
  if (isset($_POST['email']) && isset($_POST['message']) && isset($_POST['amount'])) {
//if(){
$email = $_POST['email'];
$message= $_POST['message'];
$amount= $_POST['amount'];

$result = mysqli_query($con,"INSERT INTO phototest (photo,name,amount,image,entrydate) VALUES ('$message','$email','$amount','',Now())");
//$result = mysqli_query($con,"INSERT INTO phototest(photo,name,amount,image) VALUES ('tets','tets','tets','test')");
//$result=1;
 // check if row inserted or not
    if ($result) {
        // successfully inserted into database
        $response["success"] = 1;
        $response["message"] = "Task successfully created.";

        // echoing JSON response
       print(json_encode($response));
    } else {
        // failed to insert row
        $response["success"] = 0;
        $response["message"] = "Oops! An error occurred.";

        // echoing JSON response
        print(json_encode($response));
    }


 } else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) missing";

    // echoing JSON response
    print(json_encode($response));
}

//$db->db_close();
mysqli_close($con);
?>