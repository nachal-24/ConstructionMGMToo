<?php
// Fetching Values from URL.
$name = $_POST['name1'];
$email = $_POST['email1'];
$message = $_POST['message1'];
 
$email = filter_var($email, FILTER_SANITIZE_EMAIL);  
 
if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
 
$subject = $name;
 
$headers = "MIME-Version:1.0" . "\r\n";
$headers .= "Content-type:text/html; charset=UTF-8" . "\r\n";
$headers .= "'From: ". $email. "' \r\n"; // Sender's Email
$headers .= "'Cc: " . $email. "' \r\n"; // Carbon copy to Sender
$template = '<div style="padding:50px; color:white;">Hello ' . $name . ',<br/>'
. '<br/>Thank you...! For Contacting Us.<br/><br/>'
. 'Name:' . $name . '<br/>'
. 'Email:' . $email . '<br/>'
 
. 'Message:' . $message . '<br/><br/>'
. 'This is a Contact Confirmation mail.'
. '<br/>'
. 'We Will contact You as soon as possible .</div>';
$sendmessage = "<div style=\"background-color:#7E7E7E; color:white;\">" . $template . "</div>";
 
$sendmessage = wordwrap($sendmessage, 70);
 
//mail("info@ivapapps.com", $subject, $sendmessage, $headers);

//Hari Added on 25-08
$to = "info@ivapapps.com";
$subject = "IVAP APPS WEB";
$headers = "From: ".$email. " \r\n" ."CC: ".$email."";

mail($to,$subject,$message,$headers);

echo "Your Query has been received, We will contact you soon.";

} else {
echo "<span>* invalid email *</span>";
}
?>

