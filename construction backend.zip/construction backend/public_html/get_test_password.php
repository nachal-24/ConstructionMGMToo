<?php

  // array for JSON response
$response = array();

// check for required fields
//if (isset($_GET['name']) && isset($_GET['password'])) {
  
    $name = $_POST['name'];
    //$message = $_GET['message'];

    $response["success"] = 1;
    $response["message"] = $name;

    // echoing JSON response
    print(json_encode($response));
    
  
 //} else {
    // required field is missing
  //  $response["success"] = 0;
  //  $response["message"] = "Required field(s) missing";

    // echoing JSON response
   // print(json_encode($response));
//}
?> 