<?php

if (isset($_POST['fname']) && isset($_POST['lname']) && isset($_POST['mob_no']) && isset($_POST['lat']) && isset($_POST['lng']) && isset($_POST['eid']) && isset($_POST['dev_id'])) {
$api_key='AAAAGmdjm1E:APA91bHEHF7EG-vj16UfHImeYpDRHSK8EcfSwMc-LfS5fBpHmQaVeNm_SprNwf_CJ7HXhdps2XIjpyNGPfbbHm50_MEvY5gGCrZoXw432sEteerqDr3UHRpBzfaDjLO6Fr9QQhZXd2jHe11GuXXsfTkDzXF2MnBRhw';
//$device_id='ezNq588qL9s:APA91bG3CmZLSEfHWAOKzOkx3kgJ4u1JqNpKCfVVLAt6L6QeK36soI6Ypy-N_1GwqFIneMzgxZn5SpWuFYz6HuvAAn2_wJCxdzAgVDrPKlkZ2zkkX4JS4XB_gSW5TB4OMce8SeZDKAQr';
$device_id=$_POST['dev_id'];

//$data = array("success" => "1", "fname" => "php",
//"lname" =>"test","mob_no" =>"12345678","lat" =>"12.34","lng" =>"79.34","eid" =>"79");    

//$data='{ 
//"notification": {
//    "title": "Test Notifi",
//    "body": "Checking"
// },
//  "priority":10,
//  "collapse_key": "notify",
//  "time_to_live": 108,
//  "data": {
    
//    "success" : "1", 
//    "fname" : "php",
//	"lname" :"test",
//	"mob_no" :"12345678",
//	"lat" :"12.34",
//	"lng" :"79.34",
//	"eid" :"79"
//  },
 // "to" : "$device_id"
//}';

//$success=1;
//$fname='php';
//$lname='test';
//$mob_no='12345678';
//$lat='12.34';
//$lng='79.89';
//$eid='79';

$success=1;
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$mob_no=$_POST['mob_no'];
$lat=$_POST['lat'];
$lng=$_POST['lng'];
$eid=$_POST['eid'];
$title="IMSII Police";
$body="Alert";

   $data = array (
'notification'=> array(
    "title"=> $title,
    "body"=> $body,
"sound" => "emergency_alert",
"icon" => "ic_stat_police2"
  ),
            'registration_ids' => array (
                    $device_id
            ),
            'data' => array (
                    "success" => $success,
                    "fname" => $fname,
                    "lname" => $lname,
                    "mob_no" => $mob_no,
                    "lat" => $lat,
                    "lng" => $lng,
                    "eid" => $eid
                    
            )
    );
    
$data_string = json_encode($data);  

//$headers = array (
//            'Authorization: key=' . $api_key,
 //           'Content-Type: application/json'
 //   );
                                                                                                                     
$ch = curl_init('https://fcm.googleapis.com/fcm/send');                                                                      
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                                  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);   


curl_setopt($ch, CURLOPT_HTTPHEADER, array( 
'Authorization: key='.$api_key,
    'Content-Type: application/json'));                                                                                                                   
                                                                                                                     
$result = curl_exec($ch);
echo $result;
curl_close ( $ch );
}
else{
echo "required fields missing";
}
?>
