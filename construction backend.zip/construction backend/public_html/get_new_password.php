<?php

  // array for JSON response
$response = array();

// include db connect class
require_once __DIR__ . '/db_connect.php';

// connecting to db
$db = new DB_CONNECT();
  
 $con=$db->db_connect(); 

// check for required fields
if (isset($_GET['name']) && isset($_GET['password'])) {
 // if (isset($_POST['name']) && isset($_POST['password'])) {
   $name = $_GET['name']; 
   $message = $_GET['message'];
//$name = $_POST['name'];
//$message = $_POST['message'];

// get a product from products table
   // $result = mysql_query("SELECT * FROM userlogin  WHERE username = \"$name\" ");
$result = mysqli_query($con,"SELECT * FROM userlogin  WHERE username = \"$name\" ");

if (!empty($result)){
// check for empty result
        if (mysqli_num_rows($result) > 0) {
$result = mysqli_fetch_array($result);
$product = array();
$product["username"] = $result["username"];
            $product["password"] = $result["password"];
 // success
            $response["success"] = 1;
$response["message"] = "Login successful.";
            // user node
            $response["product"] = array();
array_push($response["product"], $product);
print(json_encode($response));
} else{
// no product found
            $response["success"] = 0;
            $response["message"] = "No User found";
 
            // echo no users JSON
            print(json_encode($response));
}
} else{
// no product found
            $response["success"] = 0;
            $response["message"] = "No User found";
 
            // echo no users JSON
            print(json_encode($response));
}
    
  
 } else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) missing";

    // echoing JSON response
    print(json_encode($response));
}
$db->db_close();
?> 