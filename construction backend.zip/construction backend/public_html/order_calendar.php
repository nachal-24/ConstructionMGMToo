<?php

  // array for JSON response
$response = array();

// include db connect class
require_once __DIR__ . '/db_config.php';

$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASSWORD,DB_DATABASE) or die("DB connection error");
mysqli_select_db($con,DB_DATABASE) or die ("no database");



// check for required fields
  if (isset($_POST['month']) && isset($_POST['year'])) {
 
$year = $_POST['year'];
$month = $_POST['month'];

$result = mysqli_query($con,"SELECT id,nooforders,startdate,orderscycle from eoq where YEAR(startdate)<=$year and YEAR(enddate)>=$year and MONTH(startdate)<=$month
and MONTH(enddate)>=$month");

if(!empty($result)){


 // check if row inserted or not
    if (mysqli_num_rows($result) > 0) {
        // successfully inserted into database
//$result = mysqli_fetch_array($result);

$response["orders"] = array();

while ($row=mysqli_fetch_row($result)){
$arraytask=array();
$arraytask["id"]=$row[0];
$arraytask["nooforders"]=$row[1];
$arraytask["startdate"]=$row[2];
$arraytask["orderscycle"]=$row[3];

//$task='task_'.$id;

array_push($response["orders"], $arraytask);

 }

        // echoing JSON response
       print(json_encode($response));
mysqli_free_result($result);
    } else {
        // failed to insert row
        $response["id"] = 0;
        $response["item"] = "Zero Rows";
 
        // echoing JSON response
        print(json_encode($response));
    }
    
  
 } else {
    // required field is missing
    $response["id"] = 0;
    $response["item"] = "Oops! An error occurred.";

    // echoing JSON response
    print(json_encode($response));
}

}else {
    // required field is missing
    $response["id"] = 0;
    $response["item"] = "Empty Retured";

    // echoing JSON response
    print(json_encode($response));
}

//$db->db_close();
mysqli_close($con);
?> 	