<?php

  // array for JSON response
$response = array();


$product = array();
$product["username"] = "hari";
            $product["flag"] = "dontknow";

            $response["product"] = array();
array_push($response["product"], $product);
print(json_encode($response));
?> 