<?php

  // array for JSON response
$response = array();

// include db connect class
require_once __DIR__ . '/db_config.php';

$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASSWORD,DB_DATABASE) or die("DB connection error");
mysqli_select_db($con,DB_DATABASE) or die ("no database");

$result = mysqli_query($con,"SELECT * FROM (SELECT id, taskname, STATUS , startdate, finishdate,duration,statuspercent FROM projecttask
WHERE TYPE =  'T' AND startdate < CURDATE( ) ORDER BY startdate DESC LIMIT 4)a ORDER BY startdate");
if(!empty($result)){


 // check if row inserted or not
    if (mysqli_num_rows($result) > 0) {
        // successfully inserted into database
//$result = mysqli_fetch_array($result);

$response["task"] = array();
while ($row=mysqli_fetch_row($result)){


$arraytask=array();
$arraytask["id"]=$row[0];
$arraytask["taskname"]=$row[1];
$arraytask["status"]=$row[2];
$arraytask["startdate"]=$row[3];
$arraytask["finishdate"]=$row[4];
$arraytask["duration"]=$row[5];
$arraytask["statuspercent"]=$row[6];

array_push($response["task"], $arraytask);

 }
//$response["$task"] = array();
//array_push($response["$task"], $arraytask);
        // echoing JSON response
       print(json_encode($response));
mysqli_free_result($result);
    } else {
        // failed to insert row
        $response["id"] = 0;
        $response["taskname"] = "Oops! An error occurred.";
 
        // echoing JSON response
        print(json_encode($response));
    }
    
  
 } else {
    // required field is missing
    $response["id"] = 0;
    $response["taskname"] = "Required field(s) missing";

    // echoing JSON response
    print(json_encode($response));
}

//$db->db_close();
mysqli_close($con);
?> 