<?php
 
/*
 * All database connection variables
 */
 
define('DB_USER', "u550870318_ivap"); // db user
define('DB_PASSWORD', "15-11-1990"); // db password (mention your db password here)
define('DB_DATABASE', "u550870318_test"); // database name
define('DB_SERVER', "mysql.hostinger.in");// db server
?>