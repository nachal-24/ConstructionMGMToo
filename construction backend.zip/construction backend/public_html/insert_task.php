<?php

  // array for JSON response
$response = array();

// include db connect class
//require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/db_config.php';
// connecting to db
//$db = new DB_CONNECT();
  
 //$con=$db->db_connect(); 
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASSWORD,DB_DATABASE) or die("DB connection error");
mysqli_select_db($con,DB_DATABASE) or die ("no database");
// check for required fields
  if (isset($_POST['taskname']) && isset($_POST['duration']) && isset($_POST['startdate']) 
&& isset($_POST['finishdate']) && isset($_POST['status']) && isset($_POST['type'])) {
 
$taskname = $_POST['taskname'];
$duration= $_POST['duration'];
$startdate= $_POST['startdate'];
$finishdate= $_POST['finishdate'];
$status= $_POST['status'];
$type= $_POST['type'];
$estcost=$_POST['estcost'];

if(isset($_POST['predecessors'])){
$predecessors= $_POST['predecessors'];}
else
{
$predecessors='NULL';
}

if(isset($_POST['resources'])){
$resources= $_POST['resources'];}
else
{
$resources='NULL';
}

$result = mysqli_query($con,"INSERT INTO projecttask(taskname,duration,startdate,finishdate,predecessors,resources,status,type,esttotcost) 
				VALUES('$taskname','$duration','$startdate','$finishdate','$predecessors','$resources','$status','$type','$estcost')");

 // check if row inserted or not
    if ($result) {
        // successfully inserted into database
        $response["success"] = 1;
        $response["message"] = "Task successfully created.";
 
        // echoing JSON response
       print(json_encode($response));
    } else {
        // failed to insert row
        $response["success"] = 0;
        $response["message"] = "Oops! An error occurred.";
 
        // echoing JSON response
        print(json_encode($response));
    }
    
  
 } else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) missing";

    // echoing JSON response
    print(json_encode($response));
}

//$db->db_close();
mysqli_close($con);
?> 