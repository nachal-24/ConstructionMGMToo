<?php

  // array for JSON response
$response = array();

// include db connect class
//require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/db_config.php';
// connecting to db
//$db = new DB_CONNECT();
  
 //$con=$db->db_connect(); 
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASSWORD,DB_DATABASE) or die("DB connection error");
mysqli_select_db($con,DB_DATABASE) or die ("no database");

// check for required fields
  if (isset($_POST['optordersize']) && isset($_POST['nooforders']) && isset($_POST['startdate']) 
&& isset($_POST['finishdate']) && isset($_POST['orderscycle']) && isset($_POST['totmincost']) 
&& isset($_POST['item']) && isset($_POST['type']) && isset($_POST['carryingcost']) && isset($_POST['costperorder'])
&& isset($_POST['totalqty']) && isset($_POST['totaldays'])
&& isset($_POST['maxinvlevel']) && isset($_POST['prodrate']) && isset($_POST['taskdetail'])) {
 
$optordersize = $_POST['optordersize'];
$nooforders= $_POST['nooforders'];
$startdate= $_POST['startdate'];
$enddate= $_POST['finishdate'];
$orderscycle= $_POST['orderscycle'];
$totmincost= $_POST['totmincost'];
$item= $_POST['item'];
$type= $_POST['type'];
$carryingcost= $_POST['carryingcost'];
$costperorder= $_POST['costperorder'];
$totalqty= $_POST['totalqty'];
$totaldays= $_POST['totaldays'];
$maxinvlevel=$_POST['maxinvlevel'];
$prodrate=$_POST['prodrate'];
$taskdetail= $_POST['taskdetail'];


$result = mysqli_query($con,"INSERT INTO eoq(item,totalquantity,costperorder,carryingcost,totaldays,
optimumorderSize,totinvcost,nooforders,orderscycle,startdate,enddate,prodrate,maxinvlevel,type,taskdetail) 
				VALUES('$item','$totalqty','$costperorder','$carryingcost','$totaldays',
'$optordersize','$totmincost','$nooforders','$orderscycle','$startdate','$enddate','$prodrate','$maxinvlevel','$type','$taskdetail')");

 // check if row inserted or not
    if ($result) {
        // successfully inserted into database
        $response["success"] = 1;
        $response["message"] = "Task successfully created.";
 
        // echoing JSON response
       print(json_encode($response));
    } else {
        // failed to insert row
        $response["success"] = 0;
        $response["message"] = "Oops! An error occurred.";
 
        // echoing JSON response
        print(json_encode($response));
    }
    
  
 } else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) missing";

    // echoing JSON response
    print(json_encode($response));
}

//$db->db_close();
mysqli_close($con);
?> 