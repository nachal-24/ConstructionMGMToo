<?php

$response = array();

// include db connect class
require_once __DIR__ . '/db_connect.php';

// connecting to db
$db = new DB_CONNECT();
  
 $con=$db->db_connect(); 
 
 
 if($_SERVER['REQUEST_METHOD']=='POST'){
 
 $image = $_POST['image'];
                $name = $_POST['name'];
 
 //require_once('dbConnect.php');
 
 $sql ="SELECT id FROM phototest ORDER BY id ASC";
 
 $res = mysqli_query($con,$sql);
 
 $id = 0;
 
 while($row = mysqli_fetch_array($res)){
 $id = $row['id'];
 }
 
 $path = "images/$id.png";
 
 $actualpath = "http://ivapapps.16mb.com/$path";
 
 $sql = "INSERT INTO phototest (photo,name) VALUES ('$actualpath','$name')";
 
 if(mysqli_query($con,$sql)){
 file_put_contents($path,base64_decode($image));
 echo "Successfully Uploaded";
 }
 
 mysqli_close($con);
 }else{
 echo "Error";
 }
 
 $db->db_close();
?> 