<?php
session_start();
if(!isset($_SESSION['user']))
{
 header("Location: login.php");
}
include_once __DIR__ .'/db_config.php';

$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASSWORD,DB_DATABASE) or die("DB connection error");
mysqli_select_db($con,DB_DATABASE) or die ("no database");

if(!isset($_SESSION['user']))
{
 header("Location: login.php");
}

if(isset($_POST['btn-signup']))
{
 //$uname = mysql_real_escape_string($_POST['uname']);
 $email = $_POST['email'];
 //$upass = md5(mysql_real_escape_string($_POST['pass']));
 $upass = $_POST['pass'];
 $uname = $_POST['name'];
 $urole = $_POST['role'];

 //if(mysql_query("INSERT INTO users(username,email,password) VALUES('$uname','$email','$upass')"))
 if(mysqli_query($con,"INSERT INTO userlogin(username,password,name,role) VALUES('$email','$upass','$uname','$urole')"))
 {
  ?>
        <script>alert('successfully registered ');</script>
        <?php
 }
 else
 {
  ?>
        <script>alert('error while registering you...');</script>
        <?php
 }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registration</title>
<link rel="stylesheet" href="style.css" type="text/css" />

</head>
<body>
<div id="header">
 <div id="left">
    <label>Construction Management</label>
    </div>
    <div id="right">
     <div id="content">
         <?php echo $userRow['username']; ?>&nbsp;<a href="logout.php?logout">Sign Out</a>
        </div>
    </div>
</div>
<center>
<div id="login-form">
<form method="post">
<table align="center" width="30%" border="0">
<tr>
<td><input type="text" name="name" placeholder="User Name" required /></td>
</tr>
<tr>
<td><input type="text" name="role" placeholder="User Role" required /></td>
</tr>
<tr>
<td><input type="email" name="email" placeholder="New User Email" required /></td>
</tr>
<tr>
<td><input type="password" name="pass" placeholder="New User Default Password" required /></td>
</tr>
<tr>
<td><button type="submit" name="btn-signup">Add New User</button></td>
</tr>
<tr>
<td><a href="login.php">Sign In Here</a></td>
</tr>
</table>
</form>
</div>
</center>
</body>
</html>