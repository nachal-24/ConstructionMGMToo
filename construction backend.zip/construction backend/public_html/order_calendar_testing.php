<?php

  // array for JSON response
$response = array();

// include db connect class
//require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/db_config.php';
// connecting to db
//$db = new DB_CONNECT();
  
 //$con=$db->db_connect(); 
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASSWORD,DB_DATABASE) or die("DB connection error");
mysqli_select_db($con,DB_DATABASE) or die ("no database");

// check for required fields
 // if (isset($_POST['id'])) {
 
$id = $_POST['id'];
//$ids="(1,4,7)";


$result = mysqli_query($con,"SELECT * FROM eoq where id IN $id ");
if (!empty($result)){

 // check if row inserted or not
    if (mysqli_num_rows($result) > 0) {
$response["orders"] = array();
	while($row=mysqli_fetch_row($result)){
$arraytask=array();
        // successfully inserted into database
        $arraytask["item"] = $row[1];
        $arraytask["totalquantity"] = $row[2];
	$arraytask["costperorder"] = $row[3];
	$arraytask["carryingcost"] = $row[4];
	$arraytask["totaldays"] = $row[5];
	$arraytask["optimumordersize"] = $row[6];
	$arraytask["totinvcost"] = $row[7];
$arraytask["nooforders"] = $row[8];
$arraytask["orderscycle"] = $row[9];
$arraytask["startdate"] = $row[10];
$arraytask["enddate"] = $row[11];
$arraytask["prodrate"] = $row[12];
$arraytask["maxinvlevel"] = $row[13];
$arraytask["type"] = $row[14];

array_push($response["orders"], $arraytask);
        }
// echoing JSON response
       print(json_encode($response));
    } else {
        // failed to insert row
        $response["success"] = 0;
        $response["message"] = "Oops! An error occurred.";
 
        // echoing JSON response
        print(json_encode($response));
    }
    }
else{
 // failed to insert row
        $response["success"] = 0;
        $response["message"] = "Oops! No rows returned.";
 
        // echoing JSON response
        print(json_encode($response));
}
  
 //} else {
    // required field is missing
 //   $response["success"] = 0;
  //  $response["message"] = "Required field(s) missing";

    // echoing JSON response
  //  print(json_encode($response));
//}

//$db->db_close();
mysqli_close($con);
?> 